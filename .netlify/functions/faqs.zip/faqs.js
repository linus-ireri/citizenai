// Centralized FAQ and greeting data for Lino.AI bots
// Keeping data in one place avoids duplication across multiple Netlify functions.

const greetingResponses = {
  "who are you": "I'm Lino.AI assistant. How can I help you?",
  "who are you?": "I'm Lino.AI assistant. How can I help you?",
  "hello": "Hello! I'm Lino.AI assistant. How can I help you?",
  "hi": "Hi there! I'm Lino.AI assistant. How can I help you?",
  "hey": "Hey! I'm Lino.AI assistant. How can I help you!",
  "how are you": "I'm doing great, thanks for asking! I'm Lino.AI assistant. How can I help you?",
  "how are you?": "I'm doing great, thanks for asking! I'm Lino.AI assistant. How can I help you?",
  "good morning": "Good morning! I'm Lino.AI assistant. How can I help you?",
  "good afternoon": "Good afternoon! I'm Lino.AI assistant. How can I help you?",
  "good evening": "Good evening! I'm Lino.AI assistant. How can I help you?"
};

const linoAIResponses = {
  "lino ai": "Lino.AI is a technology company led by Ireri Linus Mugendi, specializing in chatbot engineering, AI integration, LLM hosting, fine-tuning, and Retrieval-Augmented Generation (RAG) implementation.",
  "what is lino.ai": "Lino.AI is a technology company led by Ireri Linus Mugendi, specializing in chatbot engineering, AI integration, LLM hosting, fine-tuning, and Retrieval-Augmented Generation (RAG) implementation.",
  "what does lino.ai do": "Lino.AI specializes in chatbot engineering, AI integration, LLM hosting, fine-tuning, Retrieval-Augmented Generation (RAG) implementation using graph knowledge vector databases, website creation, and all aspects of software engineering.",
  "who is lino.ai": "Lino.AI is led by Ireri Linus Mugendi and specializes in AI and software engineering services.",
  "who is ireri linus mugendi": "Ireri Linus Mugendi is the leader of Lino.AI, specializing in AI and software engineering.",
  "contact lino.ai": "You can contact Lino.AI at lino.ai.bot@gmail.com or visit our website at https://lino-ai-co.netlify.app",
  "lino.ai contact": "You can contact Lino.AI at lino.ai.bot@gmail.com or visit our website at https://lino-ai-co.netlify.app",
  "lino.ai services": "Lino.AI offers chatbot engineering, AI integration, LLM hosting, fine-tuning, RAG implementation, website creation, and software engineering services.",
  "lino.ai website": "Visit Lino.AI at https://lino-ai-co.netlify.app",
  "lino.ai email": "Contact Lino.AI at lino.ai.bot@gmail.com"
};

module.exports = { greetingResponses, linoAIResponses };

const axios = require("axios");

exports.handler = async function (event, context) {
  try {
    console.log("=== OpenRouter API Test ===");
    console.log("Environment check:");
    console.log("- API Key exists:", !!process.env.OPENROUTER);
    console.log("- API Key length:", process.env.OPENROUTER ? process.env.OPENROUTER.length : 0);
    console.log("- API Key preview:", process.env.OPENROUTER ? `${process.env.OPENROUTER.substring(0, 10)}...` : "Not set");

    if (!process.env.OPENROUTER) {
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          error: "API key not configured",
          message: "OPENROUTER environment variable is not set in Netlify",
          solution: "Add OPENROUTER environment variable in your Netlify dashboard"
        }),
      };
    }

    console.log("Making test API call to OpenRouter...");
    
    const testResponse = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "mistralai/mistral-small-3.2-24b-instruct:free",
        messages: [
          { role: "user", content: "Say 'Hello from Lino.AI!'" }
        ],
        max_tokens: 50,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log("✅ API call successful!");
    console.log("Response status:", testResponse.status);
    console.log("Response data:", JSON.stringify(testResponse.data, null, 2));

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        success: true,
        message: "OpenRouter API connection successful!",
        apiKeyConfigured: true,
        response: testResponse.data,
        model: "mistralai/mistral-small-3.2-24b-instruct:free"
      }),
    };

  } catch (error) {
    console.error("❌ API Test Failed:");
    console.error("Error message:", error.message);
    console.error("Error status:", error.response?.status);
    console.error("Error data:", error.response?.data);
    
    let errorMessage = "Unknown error";
    let solution = "Check your API key and try again";
    
    if (error.response?.status === 401) {
      errorMessage = "Invalid API key";
      solution = "Check your OpenRouter API key in Netlify environment variables";
    } else if (error.response?.status === 429) {
      errorMessage = "Rate limit exceeded";
      solution = "You've hit your OpenRouter rate limit. Try again later or upgrade your plan";
    } else if (error.response?.status === 402) {
      errorMessage = "Payment required";
      solution = "Your OpenRouter account needs payment or has insufficient credits";
    } else if (!error.response) {
      errorMessage = "Network error";
      solution = "Check your internet connection and try again";
    }
    
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        error: "API connection failed",
        message: errorMessage,
        solution: solution,
        details: error.response?.data || error.message,
        status: error.response?.status
      }),
    };
  }
}; 
const axios = require("axios");

exports.handler = async function (event, context) {
  try {
    console.log("Testing simple API call without context...");
    
    if (!process.env.OPENROUTER) {
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          error: "API key not found"
        }),
      };
    }

    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "mistralai/mistral-small-3.2-24b-instruct:free",
        messages: [
          { role: "system", content: "You are a helpful AI assistant." },
          { role: "user", content: "Hello, this is a test message." }
        ],
        max_tokens: 100,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log("Simple API test successful:", response.data);

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        success: true,
        message: "Simple API test successful",
        response: response.data
      }),
    };

  } catch (error) {
    console.error("Simple API test failed:", error.response?.data || error.message);
    
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        error: "Simple API test failed",
        details: error.response?.data || error.message
      }),
    };
  }
}; 
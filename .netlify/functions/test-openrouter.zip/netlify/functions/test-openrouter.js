const axios = require("axios");

exports.handler = async function (event, context) {
  try {
    console.log("Testing OpenRouter API connection...");
    console.log("API Key exists:", !!process.env.OPENROUTER);
    console.log("API Key length:", process.env.OPENROUTER ? process.env.OPENROUTER.length : 0);

    if (!process.env.OPENROUTER) {
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          error: "API key not found",
          message: "OPENROUTER environment variable is not set"
        }),
      };
    }

    // Test 1: Simple API call
    console.log("Making test API call...");
    
    const response = await axios.post(
      "https://openrouter.ai/api/v1/chat/completions",
      {
        model: "mistralai/mistral-small-3.2-24b-instruct:free",
        messages: [
          { role: "user", content: "Hello, this is a test message." }
        ],
        max_tokens: 50,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENROUTER}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log("API Response Status:", response.status);
    console.log("API Response Data:", JSON.stringify(response.data, null, 2));

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        success: true,
        message: "API connection successful",
        response: response.data,
        model: "mistralai/mistral-small-3.2-24b-instruct:free"
      }),
    };

  } catch (error) {
    console.error("API Test Error:", error.response?.data || error.message);
    
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        error: "API connection failed",
        details: error.response?.data || error.message,
        status: error.response?.status,
        message: "Check your API key and model availability"
      }),
    };
  }
}; 